---
name: Alpine Celestial
colors:
  surface: '#0e141b'
  surface-dim: '#0e141b'
  surface-bright: '#343a42'
  surface-container-lowest: '#090f16'
  surface-container-low: '#161c23'
  surface-container: '#1a2027'
  surface-container-high: '#252a32'
  surface-container-highest: '#2f353d'
  on-surface: '#dde3ed'
  on-surface-variant: '#bbcac6'
  inverse-surface: '#dde3ed'
  inverse-on-surface: '#2b3139'
  outline: '#859490'
  outline-variant: '#3c4947'
  surface-tint: '#4fdbc8'
  primary: '#4fdbc8'
  on-primary: '#003731'
  primary-container: '#14b8a6'
  on-primary-container: '#00423b'
  inverse-primary: '#006b5f'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#4cd7f6'
  on-tertiary: '#003640'
  tertiary-container: '#00b4d2'
  on-tertiary-container: '#00414d'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#71f8e4'
  primary-fixed-dim: '#4fdbc8'
  on-primary-fixed: '#00201c'
  on-primary-fixed-variant: '#005048'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#0e141b'
  on-background: '#dde3ed'
  surface-variant: '#2f353d'
typography:
  display:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 30px
    letterSpacing: 0em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system channels the quiet, awe-inspiring majesty of the Annapurna sanctuary under a star-filled Himalayan sky. It serves serious mountaineers, high-altitude trekkers, and luxury expeditioners seeking expedition logistics and booking out of Pokhara. 

The aesthetic is a union of **Glassmorphism** and **Tactile Modernism**, contrasted against atmospheric midnight alpine slates. Frosted crystalline overlays evoke sub-zero ice sheets, paired with luminous teal altitude telemetry and razor-sharp sunrise coral warnings. Every interaction balances technical mountaineering precision with visceral, expeditionary romance: high legibility under harsh lighting conditions, disciplined data density, and layered spatial depth mimicking the stratified crests of the Machapuchare ridge lines.

## Colors

The palette is engineered for high-altitude visual immersion, contrasting bottomless alpine night skies against hyper-focused luminous highlights.

- **Background & Atmospheric Canvas**: Base canvas sits at midnight alpine slate (`#0B1118`), lifting into elevation steps at `#101923` and `#152230`. 
- **Containers & Surfaces**: Frosted functional surfaces leverage `#1B2A3B` and `#223448`, creating clear foreground separation while maintaining atmospheric mood.
- **Borders & Crystalline Seams**: Structural division uses low-luminance ice-sheer borders (`#2D4259`), rising to illuminated teal rim-lighting (`#38516D` to `#14B8A6`) on interactive focus.
- **Accents & Telemetry**: Primary expeditions and confirmations draw from Alpine Cyan and Glacial Teal (`#14B8A6`, `#06B6D4`, `#2DD4BF`).
- **Sunrise Warnings & Milestones**: Acclimatization alerts, summit windows, and high-priority booking signals utilize radiant Annapurna sunrise amber and coral (`#F59E0B`, `#FB923C`, `#FF7849`).

## Typography

The typographic hierarchy enforces immediate technical clarity under extreme environmental glare or dim basecamp tents.

- **Display & Headlines (Space Grotesk)**: Architectural, geometric, and assertive. Carries structural authority for peak names (Annapurna I, Dhaulagiri), elevation tallies, and booking hero banners.
- **Narrative & Body (Plus Jakarta Sans)**: Highly legible, open-aperture sans-serif designed for prolonged reading across trek itineraries, gear manifests, and permit requirements.
- **Instrumentation & Telemetry (JetBrains Mono)**: Reserved for high-precision technical data: GPS coordinates, barometric pressure, departure timestamps, permit serial codes, and route difficulty grades.

## Layout & Spacing

The system runs on a responsive 12-column grid for desktop (`>1024px`), reflowing to an 8-column layout for tablets (`768px - 1023px`), and a tight 4-column structure for mobile viewports (`<768px`).

- **Vertical Rhythm**: Built around a strict 4px base increment, scaling up to expansive expedition spreads. Ample outer margins (`margin: 3rem`) mimic the broad horizons of the Pokhara Valley and lakeside approach.
- **Data Density**: Booking sidebars, gear lists, and telemetry widgets leverage compact `space-xs` and `space-sm` internal paddings to keep critical expedition metrics within immediate eye-tracking reach without scrolling.
- **Section Transitions**: Major narrative phases (e.g., basecamp preparation to summit push) utilize `space-xl` gaps, paired with subtle horizontal gradient seams matching celestial border tones.

## Elevation & Depth

Spatial depth relies on atmospheric ambient layering and frosted glassmorphism rather than artificial black drop-shadows.

1. **Ground Zero (Base Canvas)**: Deep slate `#0B1118`, completely flat and light-absorbent.
2. **Terrain Layer (Cards & Panels)**: Elevated to `#152230` with `backdrop-filter: blur(16px)` and an internal frosted edge using a 1px border colored `#2D4259` at 60% opacity.
3. **Floating Instrumentation (Telemetry Pills, Popovers, Drawers)**: `#1B2A3B` with `backdrop-filter: blur(24px)`. Augmented by an ambient cyan rim glow: `box-shadow: 0 0 20px -5px rgba(20, 184, 166, 0.18)`.
4. **Modal Peaks (Expedition Booking Confirmations, Weather Alerts)**: Suspended at `#223448` with crisp 1px borders of `#38516D`, ringed by a diffuse midnight shadow: `box-shadow: 0 24px 48px -12px rgba(4, 7, 11, 0.75)`.

## Shapes

The design system maintains disciplined, rounded geometry (`0.5rem` / `8px` baseline). 

- **Primary Cards & Containers**: Use `rounded-lg` (`1rem` / `16px`) to balance mechanical equipment aesthetics with high-end mountaineering hospitality.
- **Telemetry Indicators & Badges**: Utilize full-capsule pill contours (`rounded-full` / `9999px`) to visually emulate alpine watch dials, oxygen canisters, and compass housings.
- **Inputs & Action Triggers**: Retain standard baseline radius (`0.5rem`) for firm tactile presence.

## Components

### Buttons
- **Primary (Summit Action)**: Glacial Teal gradient fill (`#14B8A6` to `#06B6D4`), dark slate text (`#0B1118`, 700 weight), 1px interior high-sheen white overlay (15% opacity), pill-rounded with hover glow `box-shadow: 0 0 16px rgba(20, 184, 166, 0.4)`.
- **Secondary (Itinerary/Details)**: Dark frosted slate `#1B2A3B`, border `#2D4259`, text `#2DD4BF`. On hover: border transitions to `#14B8A6`, surface brightens to `#223448`.
- **Destructive/Critical (Evacuation/Cancel)**: Deep crimson-slate background with Amber/Coral `#FF7849` border and text.

### Telemetry Pills & Chips
- Compact, monospaced metadata modules (`JetBrains Mono`).
- Slate-tinted translucent background (`rgba(27, 42, 59, 0.75)`), with left-aligned pulsating status micro-dots (Teal for "Route Open", Amber for "Weather Window Closing", Coral for "High Wind Warning").

### Cards (Expedition & Route Modules)
- Frosted dark container (`#152230` at 85% opacity, `backdrop-filter: blur(16px)`).
- 1px hairline perimeter border (`#2D4259`).
- Split-tier layout: High-contrast peak photography at top, technical elevation/duration metrics in a segmented telemetry rail below, closing with a prominent booking call-to-action.

### Input Fields & Selectors
- Background `#101923`, border 1px solid `#2D4259`, text `#E2E8F0`.
- Focus state: border activates to `#14B8A6` with an inner telemetry aura `box-shadow: 0 0 0 1px #14B8A6`.
- Helper labels render in `JetBrains Mono` (`label-sm`) in muted alpine frost (`#94A3B8`).

### Selection Controls (Checkboxes & Radios)
- Unchecked: 1px border `#38516D`, background `#101923`.
- Checked: Vivid cyan fill (`#14B8A6`) housing an ink-black tick icon (`#0B1118`).
- Radio selections feature a centered luminous dot encircled by an unclipped cyan halo.

### Altitude Profile & Elevation Tracker (Domain Component)
- Vector topographic line charts rendered in `#2DD4BF` sitting over a vertical gradient fading into `#0B1118`.
- Interactive waypoints (e.g., Deurali, Machapuchare Base Camp) indicated by amber `#F59E0B` circular radar pins that open frosted glass popovers detailing altitude, oxygen saturation norms, and tea-house inventory.