---
name: Pokhara Himalayan Horizon
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3d4947'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6d7a77'
  outline-variant: '#bcc9c6'
  surface-tint: '#006a61'
  primary: '#00685f'
  on-primary: '#ffffff'
  primary-container: '#008378'
  on-primary-container: '#f4fffc'
  inverse-primary: '#6bd8cb'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#825100'
  on-tertiary: '#ffffff'
  tertiary-container: '#a36700'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#89f5e7'
  primary-fixed-dim: '#6bd8cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#005049'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  meta-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
The design system embodies the exhilarating clarity of the Annapurna mountain range meeting the serene mirror of Phewa Lake. It is crafted specifically for high-intent adventure travelers, trekkers, and cultural explorers seeking reliability, frictionless booking, and breathtaking discovery.

The style blends **Modern Clean Editorial** with subtle atmospheric touches. Generous white space mirrors the vast Himalayan skies, while crisp structural cards and tactile layers evoke dependable alpine equipment. The emotional experience balances serenity and thrilling momentum—conveying crisp mountain air, trustworthy operations, and instant accessibility without overwhelming visual noise.

## Colors
The palette captures the crisp alpine atmosphere of Pokhara:
- **Primary Teal (`#0D9488` / Deep `#0F766E`)**: Represents glacial waters and alpine flora. Used for primary calls-to-action, active indicators, and interactive highlights.
- **Deep Navy & Charcoal (`#0F172A` / `#1E293B`)**: Echoes granite peaks and dawn ridgelines. Anchors headlines, primary typography, high-contrast badges, and grounding navigational frames.
- **Glacial Backgrounds (`#EEF6FB` canvas / `#E0F2FE` soft tint)**: Provides an airy, cool canvas that reduces eye strain and contrasts sharply against white content blocks.
- **Warm Amber & Coral (`#F59E0B` / `#F43F5E`)**: Evokes prayer flags and high-altitude gear; reserved for alerts, urgent booking states, verified badges, and discount tags.
- **Pure Crisp White (`#FFFFFF`)**: Strictly reserved for foreground cards, search shells, sheets, and elevated overlays to provide absolute clarity.

## Typography
The system uses **Plus Jakarta Sans** across display, body, and UI controls for a friendly, modern, and readable aesthetic. Its geometric clarity gives trek itineraries and pricing tables an approachable structure. 

To impart technical competence and precision (such as altitude meters, GPS coordinates, dates, and departure times), **JetBrains Mono** is utilized as the auxiliary data/spec font (`meta-mono`). 

### Hierarchy Rules
- Maintain tight letter-spacing for large hero displays to prevent float.
- Avoid using pure black for text; rely entirely on `#0F172A` for primary headlines and `#64748B` for body copy to prevent harsh visual vibrating on glacial tinted backgrounds.
- All pricing lockups pair a bold numeric Plus Jakarta Sans figure with a `meta-mono` currency indicator.

## Layout & Spacing
The layout adheres to a 12-column responsive fluid grid designed around dynamic adventure showcases and dense booking filters:
- **Desktop (1200px+)**: 12 columns, 24px (`gutter`) gutters, 32px (`margin`) outer margins, maximum container width of 1280px centered.
- **Tablet (768px - 1199px)**: 8 columns, 16px (`gutter-sm`) gutters, 24px page margins.
- **Mobile (&lt;767px)**: 4 columns, 16px gutters, 16px (`margin-mobile`) margins.

Vertical rhythm relies on generous intervals (`space-xl` between modular sections) to prevent choice overload. Adventure booking flows prioritize immediate access with a persistent floating or anchored bottom search console on mobile.

## Elevation & Depth
Depth mimics natural daylight over soft mountain mist. Hard, heavy drop shadows are forbidden. Instead, depth is achieved through layered surfaces and diffused atmospheric shadows tinted with deep slate:

1. **Canvas Tier (Base)**: `#EEF6FB` background tint creates subtle contrast with content containers.
2. **Surface Tier (Resting)**: `#FFFFFF` panels with a microscopic outline (`rgba(15, 23, 42, 0.05)`) and a diffused light shadow: `0 4px 20px -2px rgba(15, 23, 42, 0.04)`.
3. **Hover Tier (Interactive)**: Activity cards elevate smoothly on hover: `0 12px 28px -4px rgba(13, 148, 136, 0.08), 0 4px 10px -2px rgba(15, 23, 42, 0.04)`.
4. **Overlay Tier (Modals & Sheets)**: Booking checkout panels, calendars, and floating bottom sheets sit at highest priority with an ambient shadow: `0 24px 48px -12px rgba(15, 23, 42, 0.16)`.

## Shapes
The system implements level `2` roundedness (8px base, 16px `rounded-lg`, 24px `rounded-xl`). 
- **Buttons, badges, and search inputs** feature unified 8px to 12px curvature, offering tactile softness without drifting into childish novelty.
- **Adventure cards & itinerary modules** leverage 16px (`rounded-lg`) corners with `overflow: hidden` to ensure imagery (paragliding takeoffs, mountain passes) feels contemporary and organic.
- **Floating search docks & filter pills** use full pill radii to visually detach from the structural grid.

## Components

### Buttons
- **Primary**: Solid teal (`#0D9488`), white text, semi-bold. On hover, shifts to `#0F766E` with subtle upward transform (`-1px`).
- **Secondary**: Translucent sky background (`#E0F2FE`), teal text (`#0F766E`). Hover transitions to solid tint with border.
- **Tertiary / Ghost**: Crisp navy text (`#0F172A`), no border, slight slate wash on hover.

### Cards (Adventure & Tour Tiles)
- Built on crisp `#FFFFFF` backgrounds with 16px border-radius.
- Aspect ratio 16:10 for destination imagery, featuring an overlay badge for trip duration or difficulty (e.g., "Intermediate • 4 Days") styled in `meta-mono`.
- Bottom slot displays dynamic pricing: large navy numeral (`#0F172A`) paired with primary teal action buttons.

### Inputs & Date Range Selectors
- Background: `#FFFFFF` with 1px border in `#CBD5E1`.
- Focused state: Border transitions to `#0D9488` with a 3px outer ring tinted at `rgba(13, 148, 136, 0.15)`.
- Calendar picker popovers feature round-cornered range selections highlighted in `#E0F2FE` with teal endpoints.

### Chips & Tags
- **Activity Filter Chips**: White background with slate border; turns solid `#0F172A` with white text when selected.
- **Alert & Status Chips**: Amber-tinted background (`#FEF3C7`) with dark amber text (`#92400E`) for limited seat alerts ("Only 2 spots left") and weather warnings.

### Checkboxes & Radios
- Rounded 4px squares for checkboxes, circles for radio buttons.
- Inactive: `#E2E8F0` border. Active: Solid `#0D9488` background with an animated white check/dot icon.

### Domain-Specific Components
- **Elevation / Itinerary Stepper**: Vertical timeline using teal nodes and subtle grey connector lines with altitude meters highlighted in `meta-mono`.
- **Weather / Lake Condition Badge**: Floating pill with live temperature, visibility stats, and subtle micro-icons.